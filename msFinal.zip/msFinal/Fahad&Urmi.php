<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - Makemylove | About :: Make My Love
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!--font-Awesome-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--font-Awesome-->
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
 <?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">Weedings Story</li>
     </ul>
   </div>
 	<div class="aboutUs">
 		<h4>About Fahad & Urmi's Weedings</h4>
    			<p>"Firstly, we are very much thankful to Jeevansathi to provide us a platform where we could meet a special person we are looking for. First, we impressed with each others profile.Thanks to Shuvo-dristy.com for recommending his profile to me. Next, we started talking and we didn't even realize that we were talking for 3 hours in the first telephonic conversation itself. Soon we decided to meet. Its just 2 meetings and we are committed to each other. We are engaged and our marriage is being planned by both the families and soon we will tie the knot. Thanks again to Shuvo-dristy.com team for helping me to find my Shuvo-dristy.com</p>
 	</div>
  </div>
</div>
<div class="about_bottom">
	<div class="container">
		<h3>Fahad & Urmi's Weedings Pictures </h3>
	   <!--<div class="col-md-4 about_grid1">-->
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="images/s7.jpg"  class="img-responsive" alt="" style="width: 50%" /></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			 </li>
	       </ul>
	   </div>

	   <div class="clearfix"> </div>
	</div>
</div>


<?php include_once("footer.php");?>

</body>
</html>	