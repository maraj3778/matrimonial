<?php
	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "matrimony";

	$con = new mysqli($host, $username, $password, $dbname);

	if(!$con){
		die("Failed to connect database");
	}
?>