<?php
	include 'dbconn.php';
	$id = $_GET['id'];
	$sql = "DELETE FROM users WHERE id='$id'";
	$con->query($sql);
	header("location: users.php");
?>