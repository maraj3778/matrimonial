<?php
	session_start();
    if(!isset($_SESSION['id'])){
        header("location: login.php");
    }
    include 'dbconn.php';
    if (isset($_GET['active'])) {
    	$id = $_GET['active'];
    	$sql = "UPDATE users SET isApprove=1 WHERE id='$id'";
    	$con->query($sql);
    	header("location: users.php");
    }
    else if (isset($_GET['deactive'])) {
    	$id = $_GET['deactive'];
    	$sql = "UPDATE users SET isApprove=0 WHERE id='$id'";
    	$con->query($sql);
    	header("location: users.php");
    }
?>
