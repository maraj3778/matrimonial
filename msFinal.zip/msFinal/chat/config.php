<?php
//We start sessions
session_start();

//We log to the DataBase
mysql_connect('localhost', 'root', '');
mysql_select_db('matrimony');

//Webmaster Email
$mail_webmaster = 'example@example.com';

//Top site root URL
$url_root = 'http://localhost/pm/index.php/';

//Home page file name
$url_home = 'index.php';

//Design Name
$design = 'default';
?>