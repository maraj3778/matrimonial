<?php
include('config.php');
?>
<!DOCTYPE>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="<?php echo $design; ?>/style.css" rel="stylesheet" title="Style" />
        <title>Personnal Messages</title>
    </head>
    <body>
        <div class="header">
            <a href="<?php echo $url_home; ?>"><img src="<?php echo $design; ?>/images/logo1.png" alt="Members Area" height='120' width='530'/></a>
        </div>
        <div class="foot"><a href="http://localhost/msFinal/">Home</a></div>
        <div class="content">

<?php
//We check if the user is logged
if(isset($_SESSION['username']))
{
//We list his messages in a table
//Two queries are executes, one for the unread messages and another for read messages
$req1 = mysql_query('select m1.id, m1.title, m1.timestamp, count(m2.id) as reps, users.id as userid, users.username from pm as m1, pm as m2,users where ((m1.user1="'.$_SESSION['id'].'" and m1.user1read="no" and users.id=m1.user2) or (m1.user2="'.$_SESSION['id'].'" and m1.user2read="no" and users.id=m1.user1)) and m1.id2="1" and m2.id=m1.id group by m1.id order by m1.id desc');
$req2 = mysql_query('select m1.id, m1.title, m1.timestamp, count(m2.id) as reps, users.id as userid, users.username from pm as m1, pm as m2,users where ((m1.user1="'.$_SESSION['id'].'" and m1.user1read="yes" and users.id=m1.user2) or (m1.user2="'.$_SESSION['id'].'" and m1.user2read="yes" and users.id=m1.user1)) and m1.id2="1" and m2.id=m1.id group by m1.id order by m1.id desc');
?>
This is the list of your messages:<br />
<br />
<h3>Unread Messages:</h3>
<table>
    <tr>
        <th class="title_cell">Action</th>
        <th>Date of creation</th>
    </tr>
<?php
//We display the list of unread messages
while($dn1 = mysql_fetch_array($req1))
{
?>
    <tr>
        <td class="left"><a href="read_pm.php?id=<?php echo $dn1['id']; ?>">Show</a></td>
        
        <td><?php echo date('Y/m/d H:i:s' ,$dn1['timestamp']); ?></td>
    </tr>
<?php
}
//If there is no unread message we notice it
if(intval(mysql_num_rows($req1))==0)
{
?>
    <tr>
        <td colspan="4" class="center">You have no unread message.</td>
    </tr>
<?php
}
?>
</table>
<br />
<h3>Read Messages:</h3>
<table>
    <tr>
        <th class="title_cell">Action</th>
        <th>Date or creation</th>
    </tr>
<?php
//We display the list of read messages
while($dn2 = mysql_fetch_array($req2))
{
?>
    <tr>
        <td class="left"><a href="read_pm.php?id=<?php echo $dn2['id']; ?>">Show</a></td>
        
        <td><?php echo date('Y/m/d H:i:s' ,$dn2['timestamp']); ?></td>
    </tr>
<?php
}
//If there is no read message we notice it
if(intval(mysql_num_rows($req2))==0)
{
?>
    <tr>
        <td colspan="4" class="center">You have no read message.</td>
    </tr>
<?php
}
?>
</table>
<?php
}
else
{
    echo 'You must be logged to access this page.';
}
?>
        </div>
        
    </body>
</html>