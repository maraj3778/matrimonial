<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - Makemylove | Faq :: Make My Love
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
<?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">FAQ</li>
     </ul>
   </div>
   <dl class="faq-list">
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>How do I change my email address or password?</h4>
	</dt>
	<dd>
	<h4 class="marker1">A.</h4>
	<p class="m_4">You can change your email address on the "edit your profile" page. Here you can change some other information including Partner preferences, address and other preferences about your daily routines, habits, hobbies etc.After you've made your changes, click "Update" at the bottom of the page to save..</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>When someone Message me, where does the Message go and how do I respond?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">When a member sends you a Message, it goes straight into your onsite message Inbox. We then send an email to your personal email address to let you know that it's there.To read the messages, simply login to the site and go to your My Box, Messages. If you decide to write back, simply click "reply", write your own message and send away. Your note will go straight into the member's onsite Inbox, and we'll let them know it's there with an email to their personal email address.All communications with other members stay onsite so that you never have to give out any personal information until you feel completely ready. Then when you are, you can exchange phone numbers and even meet in person.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>How do I edit my profile?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">To update your profile, click "Edit Profile" in Members Panel menu. Be sure to save your changes at the bottom of the screen when you're done.Try to put your best foot forward with at least one photo and snappy, detailed essays about your interests. The photo is key since most people feel more comfortable writing to members they can see. Try to stay positive in your essays and let the real you shine..</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>How does "My Matches" works?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">When you create your profile or Edit My Profile, besure to complete "Partner Info" page. Based on the information you provided in this page, our system automatically match potential partner for you. You will also receive periodic email from borbodhu.com with the partner profile that matches your desire.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>IS this site safe or not?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">Yeah This site is very much safe for people. And Their personal Information must be protected</p>
	</dd>
	<!--<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>Fusce feugiat malesuada odio. Morbi nunc odio gravida atcursus neluctus a lorem. Maecenas tristiqu?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">Aenean auctor wisi et urna. Aliquarat volutpat. Duis ac turpis. Integer rutrum ante eu lacusVestibulum libero nisl porta vel scelerisque eget malesuada at neque. Vivamus eget nibh. Etiamcursus leo vel metus. Nulla facilisi. Aenean nec eros.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>Maecenas tristique orci ac sem. Duis ultricihre tra magnauae ab illo inventoa ster port rsen maet jhaslelu misleui portau?</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4 m_5">Nulla dui. Fusce feugiat malesuada odio. Morbi nunc odio gravida atcursus nec luctus a lorem. Maecenas tristique orci ac sem. Duis ultricies pharetra magna. Donec accumsan malesuada orci. Donec sit amet eros. Lorem ipsum dolor sit amet consectetuer adipiscing elit. Mauris fermentum dictum magna. Sed laoreet aliquam leo. Ut tellus dolor dapibus eget elementum vel cursus eleifend elit.</p>
	</dd>-->
   </dl>
  </div>
</div>


<?php include_once("footer.php");?>

</body>
</html>	