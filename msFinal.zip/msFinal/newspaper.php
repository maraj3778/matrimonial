
<!DOCTYPE html>
<html>
<head>
	<title>Hello Facebook</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <nav class="navbar navbar-inverse " style="background-color: #0275D8;">
	    <div class="container-fluid">
		    <div class="navbar-header">
		      <a class="navbar-brand" href="#">আজকের নিউজ</a>
		    </div>
		    <ul class="nav navbar-nav">
		      <li class="active"><a href="#">Home</a></li>
		      <li><a href="#">বাংলাদেশ</a></li>
		      <li><a href="#">আন্তজাতিক</a></li>
		      <li><a href="#">খেলা</a></li>
		    </ul> 
		    <form class="form-inline">
			    <input class="form-control mr-sm-2" type="text" placeholder="Search">
			    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
		   </form>
	  </div>
  </nav>
  
  <div class="container">
		<div class="row">
			<div class="col-md-4">
			<img src="Images/pic1.JPG" class="img-thumbnail" alt="Cinque Terre" width="304" height="236">
			  <h3><a href="#">আরও ১৬০ জনকে প্রথম<br> শ্রেণিতে নিয়োগের সুপারিশ</a></h3>
			  <p>৩৫তম বিসিএস পরীক্ষায় উত্তীর্ণ পরীক্ষার্থীদের মধ্য</br>থেকে আরও ১৬০ জনকে.. </p>
			</div>
		</div>
  </div>




	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
</body>
</html>