<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - Makemylove | About :: Make My Love
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!--font-Awesome-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--font-Awesome-->
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
 <?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page"><b>News and Events</b></li>
     </ul>
   </div>
 	<div class="aboutUs">
 		<h2>Good career effects on weeding</h2>
    			<p>"Good career always benificial. In terms of marrige function good job or good career og groom always kept on hot topics in marrige conversation section. Be a good carrer always demand a good 
    			bride. In this asia pacific location most of the marrige held on family tradition. Family
    			priority in weeding always prefferble in this area. So called family always show that what kind of job or business groom do. Actually they ensure their daughter life to keep peace and enjoyable. That's why they always become choosy to groom career. Good selary become treat well that's the throw most of the daughter's family believed </p>
 	</div>
  </div>
</div>
<div class="about_bottom">
	<div class="container">
		<h3>"Ariyaan" memeber of shuvo-dristi.com </h3>
	   <!--<div class="col-md-4 about_grid1">-->
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="images/3.jpg"  class="img-responsive" alt="" style="width: 50%" /></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			 </li>
	       </ul>
	   </div>

	   <div class="clearfix"> </div>
	</div>
</div>


<?php include_once("footer.php");?>

</body>
</html>	